# D-Fence Live Demo - Account Logins & Access

**Target Live Site**: https://dfence-sc2006.azurewebsites.net

---

## 1. Resident Portal
* **Role**: Citizen / Resident (Aisha binti Rahman)
* **Login URL**: https://dfence-sc2006.azurewebsites.net/signin
* **Email**: `resident@d-fence.local`
* **Password**: `P@ssw0rd123!`
* **Key Screen**: `/report` (Tap 'Locate me', attach snake photo, submit critical report)

---

## 2. Operations Command
* **Role**: Operations Manager (Rachel Lim)
* **Login URL**: https://dfence-sc2006.azurewebsites.net/signin
* **Email**: `ychow015@e.ntu.edu.sg`
* **Password**: `P@ssw0rd123!`
* **Key Screens**: 
  - `/ops` (Triage queue, Critical priority badge, 0-100 environmental scoring)
  - `/ops/dispatch` (Interactive OneMap road route, Leaflet map, 4h shift fatigue cap)

---

## 3. Field Officer Mobile
* **Role**: Field Officer / Cleaning Crew (Ahmad Faizal)
* **Login URL**: https://dfence-sc2006.azurewebsites.net/signin
* **Email**: `crew.demo@d-fence.local`
* **Password**: `P@ssw0rd123!`
* **Key Screen**: `/crew` (Equipment checklist, ordered stops, job acceptance & photo evidence completion)
