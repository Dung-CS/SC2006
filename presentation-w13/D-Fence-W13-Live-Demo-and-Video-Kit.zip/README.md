# D-Fence Week 13 Demo Package

This archive contains all the instructions and necessary files to present the live demo and record the 5-minute video walkthrough on https://dfence-sc2006.azurewebsites.net.

## Package Inventory

1. **D-Fence-W13-v2.pptx** — The final 18-slide PowerPoint presentation deck.
2. **LIVE_DEMO_AND_VIDEO_INSTRUCTIONS.md** — Master instruction guide for live presentation and video recording.
3. **DEMO_VIDEO_WALKTHROUGH_SCRIPT.md** — Beat-by-beat video cue sheet (what to click and what to say for the 5-minute video).
4. **D-Fence W13 Presentation Script.md** — 20-minute spoken script for the live presentation.
5. **ACCOUNTS_AND_LOGINS.md** — Quick reference for the 3 test accounts (Resident, Manager, Crew).
6. **images/**
   - `01-snake-reporting-evidence.jpg` — Evidence photo of Reticulated Python for the Resident intake report.
   - `02-drain-completion-evidence.jpg` — Verification photo for the Crew job resolution.
7. **tools/** (Optional) — Edge WebDriver automation scripts if you want the browser to drive itself while you narrate.
