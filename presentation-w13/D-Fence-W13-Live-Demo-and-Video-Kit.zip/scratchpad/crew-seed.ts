/**
 * scratchpad/crew-seed.ts
 *
 * Seeds one demo crew account and one dispatch on the live DB, or cleans them up.
 *
 * Usage:
 *   npx tsx scratchpad/crew-seed.ts          # seed
 *   npx tsx scratchpad/crew-seed.ts --cleanup # cleanup (do not run during initial seed)
 */

import { randomBytes, randomUUID, scryptSync } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, unlinkSync } from 'node:fs';
import { resolve } from 'node:path';

import { ConfigLoader } from '../src/config/ConfigLoader';
import { Database } from '../src/persistence/Database';
import { Account } from '../src/entity/Account';
import { Report } from '../src/entity/Report';
import { WorkOrder } from '../src/entity/WorkOrder';
import { GeoPoint, singaporeDate } from '../src/entity/valueTypes';
import {
  HqLocation,
  LocationContext,
  PestType,
  PriorityTier,
  ReportStatus,
  ReportType,
  Role,
  StaffSpecialisation,
  StaffStatus,
  TaskType,
  WorkOrderStatus,
} from '../src/entity/enums';
import { AccountRepository } from '../src/persistence/AccountRepository';
import { CredentialRepository } from '../src/persistence/CredentialRepository';
import { ReportRepository } from '../src/persistence/ReportRepository';
import { WorkOrderRepository } from '../src/persistence/WorkOrderRepository';
import { VehicleRepository } from '../src/persistence/VehicleRepository';
import { DispatchAssignmentRepository } from '../src/persistence/DispatchAssignmentRepository';
import { ChecklistItem, DispatchAssignment } from '../src/ports/DispatchAssignmentStore';
import { HttpClient } from '../src/boundary/gateways/HttpClient';
import { OneMapGateway } from '../src/boundary/gateways/OneMapGateway';
import { RouteStrategyFactory } from '../src/control/routing/RouteStrategyFactory';
import {
  PlannedTeamRoute,
  RouteJob,
  RouteOptimizationService,
  RouteTeam,
} from '../src/control/RouteOptimizationService';
import { generatePackingList, LOGISTICS_LOAD_BASIS, logisticsLoad } from '../src/control/LogisticsPolicy';
import { withLocalities } from '../src/control/DispatchPlanService';
import { HQ_COORDINATES } from '../src/control/DispatchRouteInputs';

interface SeedIds {
  work_order: string[];
  dispatch_assignment: string[];
  report: string[];
  local_credential: string[];
  account: string[];
}

const DIR = resolve('scratchpad');
const IDS_PATH = resolve(DIR, 'crew-seed-ids.json');
const LOGIN_PATH = resolve(DIR, 'crew-login.json');

async function seed(db: Database): Promise<void> {
  if (existsSync(IDS_PATH)) {
    console.log('Found existing crew-seed-ids.json. Please run with --cleanup first if re-seeding.');
    process.exit(1);
  }

  const today = singaporeDate(new Date());
  console.log(`Seeding demo crew dispatch for date: ${today}`);

  const accountRepo = new AccountRepository(db);
  const credRepo = new CredentialRepository(db);
  const reportRepo = new ReportRepository(db);
  const workOrderRepo = new WorkOrderRepository(db);
  const vehicleRepo = new VehicleRepository(db);
  const dispatchRepo = new DispatchAssignmentRepository(db);

  // 1. Get existing manager and resident accounts
  const residentRows = (await db.query("SELECT id FROM account WHERE role = 'Resident' LIMIT 1")) as Array<{ id: string }>;
  if (!residentRows[0]) throw new Error('No resident account found in DB');
  const residentId = residentRows[0].id;

  const managerRows = (await db.query("SELECT id FROM account WHERE role = 'OperationsManager' LIMIT 1")) as Array<{ id: string }>;
  if (!managerRows[0]) throw new Error('No manager account found in DB');
  const managerId = managerRows[0].id;

  // 1b. Clean up any previous leftover demo crew account
  const existingCrew = (await db.query("SELECT id, auth_user_id FROM account WHERE email = 'crew.demo@d-fence.local'")) as Array<{ id: string; auth_user_id: string }>;
  if (existingCrew[0]) {
    await db.query("DELETE FROM local_credential WHERE email = 'crew.demo@d-fence.local'");
    await db.query("DELETE FROM account WHERE email = 'crew.demo@d-fence.local'");
  }
  const crewAccount = new Account();
  crewAccount.id = randomUUID();
  crewAccount.email = 'crew.demo@d-fence.local';
  crewAccount.displayName = 'Ahmad Faizal (demo)';
  crewAccount.authUserId = randomUUID();
  crewAccount.emailVerified = true;
  crewAccount.role = Role.CleaningCrew;
  crewAccount.isActive = true;
  crewAccount.specialisation = StaffSpecialisation.Sanitation;
  crewAccount.hqLocation = HqLocation.Central;
  crewAccount.staffStatus = StaffStatus.Available;
  crewAccount.onCallLagHours = 0;
  crewAccount.telegramChatId = null;
  crewAccount.createdAt = new Date();

  await accountRepo.save(crewAccount);

  const password = randomBytes(18).toString('base64url');
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64);
  await credRepo.insert({
    authUserId: crewAccount.authUserId,
    email: crewAccount.email,
    salt,
    hash,
    disabled: false,
  });

  // 3. Select vehicle
  const vehicle = await vehicleRepo.findById('demo-vehicle-Central-van');
  if (!vehicle) throw new Error('Vehicle demo-vehicle-Central-van not found');

  // 4. Create 4 reports at real Singapore locations in Toa Payoh
  interface StopDef {
    woId: string;
    reportId: string;
    locality: string;
    point: GeoPoint;
    pestType: PestType;
    priority: PriorityTier;
    taskType: TaskType;
    reportType: ReportType;
    description: string;
    effortMinutes: number;
    instructions: string;
  }

  const stopDefs: StopDef[] = [
    {
      woId: randomUUID(),
      reportId: randomUUID(),
      locality: 'Blk 177 Toa Payoh Central',
      point: new GeoPoint(1.3344, 103.8502),
      pestType: PestType.Mosquito,
      priority: PriorityTier.High,
      taskType: TaskType.Fogging,
      reportType: ReportType.StandingWater,
      description: 'Stagnant water and mosquito breeding observed in perimeter drain',
      effortMinutes: 45,
      instructions: 'Carry out thorough thermal fogging around ground floor perimeter and perimeter drains.',
    },
    {
      woId: randomUUID(),
      reportId: randomUUID(),
      locality: 'Blk 185 Toa Payoh Central',
      point: new GeoPoint(1.3338, 103.8515),
      pestType: PestType.Rat,
      priority: PriorityTier.Medium,
      taskType: TaskType.DrainClearance,
      reportType: ReportType.BlockedDrain,
      description: 'Rodent burrow sightings and refuse blockage behind market stalls',
      effortMinutes: 50,
      instructions: 'Clear blocked drainage channels and clear rodent harbourage zones.',
    },
    {
      woId: randomUUID(),
      reportId: randomUUID(),
      locality: 'Blk 66 Lorong 4 Toa Payoh',
      point: new GeoPoint(1.3361, 103.8532),
      pestType: PestType.Cockroach,
      priority: PriorityTier.Medium,
      taskType: TaskType.Inspection,
      reportType: ReportType.UnclearedRefuse,
      description: 'Cockroach infestation inspection at bin chute chamber',
      effortMinutes: 30,
      instructions: 'Inspect refuse chute chamber and apply gel baiting along common areas.',
    },
    {
      woId: randomUUID(),
      reportId: randomUUID(),
      locality: 'Blk 260 Kim Keat Avenue',
      point: new GeoPoint(1.3308, 103.8576),
      pestType: PestType.Fly,
      priority: PriorityTier.Low,
      taskType: TaskType.RefuseClearance,
      reportType: ReportType.UnclearedRefuse,
      description: 'Flies gathering near communal bin loading point',
      effortMinutes: 40,
      instructions: 'Sanitise bin staging platform and remove spilled organic refuse.',
    },
  ];

  for (const s of stopDefs) {
    const report = new Report();
    report.id = s.reportId;
    report.reporterId = residentId;
    report.point = s.point;
    report.type = s.reportType;
    report.pestType = s.pestType;
    report.locationContext = LocationContext.Outdoor;
    report.injuryReported = false;
    report.estimatedCount = 3;
    report.description = s.description;
    report.clusterId = null;
    report.localityBinding = s.locality;
    report.corroborationCount = 1;
    report.submittedAt = new Date();
    report.moderatorId = managerId;
    report.moderatedAt = new Date();
    report.moderationReason = 'Approved for dispatch';
    report.workOrderId = null;
    report.applyStatus(ReportStatus.Actioned);
    await reportRepo.save(report);
  }

  // 5. Calculate real road route using OneMap
  const config = ConfigLoader.load();
  const token = config.get('ONE_MAP_TOKEN');
  const email = config.get('ONE_MAP_EMAIL');
  const http = new HttpClient();
  const oneMap = new OneMapGateway(
    http,
    'https://www.onemap.gov.sg',
    token || null,
    email ? { email, password: config.get('ONE_MAP_PASSWORD') } : null
  );

  const planner = new RouteOptimizationService(RouteStrategyFactory.create(oneMap));
  const hq = HQ_COORDINATES[HqLocation.Central];

  const jobs: RouteJob[] = stopDefs.map((s) => ({
    workOrderId: s.woId,
    point: s.point,
    locality: s.locality,
    requiredCapability: s.pestType === PestType.Mosquito ? 'VectorControl' : 'Sanitation',
    taskType: s.taskType,
    pestType: s.pestType,
    priority: s.priority,
    status: 'Assigned',
    estimatedEffortMinutes: s.effortMinutes,
  }));

  const stops = planner['stops'](hq, jobs);
  const plan = await planner['strategy'].calculateRoute(stops);
  const pool: RouteTeam = {
    teamId: 'Central-Team-1',
    hq,
    capabilities: ['VectorControl', 'Sanitation'],
    status: StaffStatus.Available,
    onCallLagHours: 0,
  };

  const [built] = withLocalities([planner['buildRoute']({ pool, teamId: 'Central-Team-1', staffCount: 1, jobs, plan }, 0)], jobs);
  if (!built) throw new Error('Failed to build route');

  // Enrich built route with authentic details
  built.crewMembers = [{ id: crewAccount.id, email: crewAccount.email, displayName: crewAccount.displayName }];
  built.vehicleId = vehicle.id;
  built.vehicleName = vehicle.name;
  built.vehicleModel = vehicle.model ?? undefined;
  built.vehicleRegistration = vehicle.registration;
  built.vehiclePhotoUrl = vehicle.photoUrl ?? undefined;
  built.isFixed = true;

  const packing = generatePackingList(jobs, 1);
  const defaultChecklist: ChecklistItem[] = packing.map((item, idx) => ({
    id: `${idx}-${item.item.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
    item: item.item,
    quantity: item.quantity,
    icon: item.icon,
    category: item.category,
    checked: false,
  }));

  built.checklist = defaultChecklist;

  // 6. Create DispatchAssignment
  const assignmentId = randomUUID();
  const assignment: DispatchAssignment = {
    id: assignmentId,
    date: today,
    teamId: 'Central-Team-1',
    crewIds: [crewAccount.id],
    vehicleId: vehicle.id,
    workOrderIds: stopDefs.map((s) => s.woId),
    computedAt: new Date().toISOString(),
    routeSnapshot: built,
    createdAt: new Date().toISOString(),
    createdBy: managerId,
    isFixed: true,
    checklist: defaultChecklist,
  };

  await dispatchRepo.save(assignment);

  // 7. Create Work Orders
  for (const s of stopDefs) {
    const order = new WorkOrder();
    order.id = s.woId;
    order.clusterId = null;
    order.assigneeId = crewAccount.id;
    order.dispatchAssignmentId = assignmentId;
    order.assignedCrewIds = [crewAccount.id];
    order.assignedVehicleId = vehicle.id;
    order.sourceReportId = s.reportId;
    order.targetPoint = s.point;
    order.taskType = s.taskType;
    order.pestType = s.pestType;
    order.scheduledDate = today;
    order.priority = s.priority;
    order.instructions = s.instructions;
    order.startedAt = null;
    order.createdAt = new Date();
    order.verifiedAt = null;
    order.cancellationReason = null;
    order.issueFlag = false;
    order.issueReason = null;
    order.applyStatus(WorkOrderStatus.Assigned);
    await workOrderRepo.save(order);
  }

  // 7b. Link workOrderId back on reports
  for (const s of stopDefs) {
    await db.query('UPDATE report SET work_order_id = $1 WHERE id = $2', [s.woId, s.reportId]);
  }

  // 8. Record seed IDs
  const seedIds: SeedIds = {
    work_order: stopDefs.map((s) => s.woId),
    dispatch_assignment: [assignmentId],
    report: stopDefs.map((s) => s.reportId),
    local_credential: [crewAccount.authUserId],
    account: [crewAccount.id],
  };

  writeFileSync(IDS_PATH, JSON.stringify(seedIds, null, 2), 'utf8');

  // 9. Write crew-login.json
  const loginData = {
    email: crewAccount.email,
    password,
    date: today,
  };
  writeFileSync(LOGIN_PATH, JSON.stringify(loginData, null, 2), 'utf8');

  console.log('Seed completed successfully:');
  console.log(`- account: 1 row (${crewAccount.id})`);
  console.log(`- local_credential: 1 row (${crewAccount.authUserId})`);
  console.log(`- report: ${stopDefs.length} rows`);
  console.log(`- dispatch_assignment: 1 row (${assignmentId})`);
  console.log(`- work_order: ${stopDefs.length} rows`);
  console.log(`IDs saved to: ${IDS_PATH}`);
  console.log(`Login saved to: ${LOGIN_PATH}`);
}

async function cleanup(db: Database): Promise<void> {
  if (!existsSync(IDS_PATH)) {
    console.log('No crew-seed-ids.json found to clean up.');
    return;
  }

  const ids: SeedIds = JSON.parse(readFileSync(IDS_PATH, 'utf8'));
  console.log('Cleaning up seeded rows in dependency order:');

  // 0. Break circular foreign key link between report and work_order
  if (ids.report?.length) {
    await db.query('UPDATE report SET work_order_id = NULL WHERE id = ANY($1::uuid[])', [ids.report]);
  }

  // 1. work_order
  if (ids.work_order?.length) {
    const res = await db.query('DELETE FROM work_order WHERE id = ANY($1::uuid[]) RETURNING id', [ids.work_order]);
    console.log(`- work_order: deleted ${res.length} rows`);
  }

  // 2. dispatch_assignment
  if (ids.dispatch_assignment?.length) {
    const res = await db.query('DELETE FROM dispatch_assignment WHERE id = ANY($1::uuid[]) RETURNING id', [ids.dispatch_assignment]);
    console.log(`- dispatch_assignment: deleted ${res.length} rows`);
  }

  // 3. report
  if (ids.report?.length) {
    const res = await db.query('DELETE FROM report WHERE id = ANY($1::uuid[]) RETURNING id', [ids.report]);
    console.log(`- report: deleted ${res.length} rows`);
  }

  // 4. local_credential
  if (ids.local_credential?.length) {
    const res = await db.query('DELETE FROM local_credential WHERE auth_user_id = ANY($1::text[]) RETURNING auth_user_id', [ids.local_credential]);
    console.log(`- local_credential: deleted ${res.length} rows`);
  }

  // 5. account
  if (ids.account?.length) {
    const res = await db.query('DELETE FROM account WHERE id = ANY($1::uuid[]) RETURNING id', [ids.account]);
    console.log(`- account: deleted ${res.length} rows`);
  }

  if (existsSync(IDS_PATH)) unlinkSync(IDS_PATH);
  if (existsSync(LOGIN_PATH)) unlinkSync(LOGIN_PATH);
  console.log('Cleanup complete. Removed id and login files.');
}

async function main(): Promise<void> {
  const db = new Database(ConfigLoader.load().get('DATABASE_URL'));
  try {
    if (process.argv.includes('--cleanup')) {
      await cleanup(db);
    } else {
      await seed(db);
    }
  } finally {
    await db.close();
  }
}

main().catch((err) => {
  console.error('Error during crew-seed execution:', err);
  process.exit(1);
});
